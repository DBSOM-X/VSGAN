__version__ = '0.5.0a0+b8e3e96'
git_version = 'b8e3e96910d13bf485aa49ae23e2c77e25ba25f1'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
